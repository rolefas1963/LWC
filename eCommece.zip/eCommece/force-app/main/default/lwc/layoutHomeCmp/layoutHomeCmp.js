import { LightningElement } from "lwc";
export default class LayoutHomeCmp extends LightningElement {
}