import { LightningElement } from "lwc";

export default class ComboboxBasic extends LightningElement {
    value = '';

    get options() {
        return [
            { label: 'Ar Concicionado', value: 'ar_condicionado' },
            { label: 'Celular', value: 'celular' },
            { label: 'Decoração', value: 'decoracao' },
            { label: 'Cama', value:'cama'}
        ];
    }

    handleChange(event) {
        this.value = event.detail.value;
    }
}
