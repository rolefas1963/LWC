import { LightningElement } from "lwc";
export default class ProductCmp extends LightningElement {
}