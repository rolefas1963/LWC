import { LightningElement } from "lwc";
export default class ListProdutoCmp extends LightningElement {
}